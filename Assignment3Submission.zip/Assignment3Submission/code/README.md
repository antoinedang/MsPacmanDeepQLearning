To set up dependencies:
    Install Python 3
    Run `pip install -r requirements.txt`


To run agent:
    `python3 play.py`

This will load the best performing agent saved in data/checkpoints/best_agent.pkl. <br>
A random seed will be used every time `play.py` is run. To set the seed manually, modify line *14* of `play.py`